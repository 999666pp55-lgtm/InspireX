// InspireX Kernel - Sector 2763
// Target: Dell Precision Xeon

void print_string(char* message, unsigned char color, int line) {
    /* 0xB8000 is the start of video memory. 
       Each line is 160 bytes (80 characters * 2 bytes each). */
    char* video_memory = (char*)(0xB8000 + (line * 160));
    int i = 0;

    while (message[i] != 0) {
        video_memory[i * 2] = message[i];     // Set the Character
        video_memory[i * 2 + 1] = color;      // Set the Color
        i++;
    }
}

void main() {
    /* Clear screen logic would go here, but for now, we just print over. */
    
    print_string("InspireX Core: Steel Engaged", 0x0A, 0); // Green Text
    print_string("Xeon Status: Precision Mode", 0x0F, 1);  // White Text
    print_string("Sector 2763 - 96GB Entry", 0x03, 2);    // Cyan Text

    // The Sentry Loop: Keep the CPU from escaping into garbage memory
    while(1);
}