; DOS Hello Wrold
;
; Assemble with nasm -o hello.com hello.asm

	org 100h

	mov dx, data
	mov ah, 09h
	int 21h
	mov ah, 04ch
	int 21h

data:
	db 'Hello, World!$'
