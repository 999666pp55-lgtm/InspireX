; This program was written to test x86 emulators (like my own)
; It checks a couple of instructions, prints Hello World and
; then calculates some number sequences and primes; Here is the 
; expected output: 

; .........                                                                       
; Hello, world!                                                                   
; 0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\]^_`abcdefghijklmnopqrstuvwxyz{|}~ 
; 
; 
; ################################################################################
; ##                                                                            ##
; ##  0 1 1 2 3 5 8 13 21 34 55 89 144 233 377 610 987                          ##
; ##                                                                            ##
; ##  0 1 4 9 16 25 36 49 64 81 100 121 144 169 196 225 256 289 324 361 400     ##
; ##                                                                            ##
; ##  2 3 5 7 11 13 17 19 23 29 31 37 41 43 47 53 59 61 67 71 73 79 83 89 97    ##
; ##                                                                            ##
; ##                                                                            ##
; ##                                                                            ##
; ##                                                                            ##
; ##                                                                            ##
; ##                                                                            ##
; ##                                                                            ##
; ##                                                                            ##
; ##                                                                            ##
; ##                                                                            ##
; ##                                                                            ##
; ##                                                                            ##
; ################################################################################

; The data is written to screen, which is at B000:8000 (video mode 3)
;
; Usage: >nasm -o x86test.com x86test.asm
;        >x86test
;
; So far only a small subset of the instruction sheet is tested
;


	org 100h

	mov ax, 0b000h
	mov ds, ax
	mov sp, 1000h

	call clear

	jmp cont

halt:
	mov ah, 04Ch
	int 21h

cont:
	mov al, '.'

	mov bx, 0
	dec bx
	cmp bx, 0ffffh
	jnz halt
	call printchr

	inc bx
	jnz halt
	call printchr

	xor cx, cx
	or bx, cx
	jnz halt
	jc halt
	call printchr

	mov cx, 08000h
	cmp cx, bx
	jbe halt
	call printchr

	add bx, cx
	jc halt
	call printchr

	add bx, bx
	adc cx, 0
	jns halt
	jc halt
	push cx
	and cx, 1
	jz halt
	call printchr

	pop cx
	stc
	mov bx, 08000h
	sbb cx, bx
	jnz halt
	jc halt
	call printchr
	
	call calltest
calltest:
	pop bx
	cmp bx, calltest
	jnz halt
	cmp sp, 1000h
	jnz halt
	call printchr

	mov bx, rettest
	push bx
	ret
rettest:
	cmp sp, 1000h
	jnz halt
	call printchr

	nop
	nop
	nop

	call printnl

	mov ax, hello
	call print
	call printnl


	mov al, 30h
ascii_loop:
	call printchr
	inc al
	cmp al, 127
	jnz ascii_loop


	mov al, '#'
	mov word [es:cursor], 160 * 5
	mov cl, 80

boxloop:
	call printchr
	dec cl
	jnz boxloop
	cmp word [es:cursor], 160 * 6
	jnz cont2
	mov cl, 80
	mov word [es:cursor], 160 * 24
	jmp boxloop

cont2:

	mov word [es:cursor], 160 * 6
	mov cl, 18
	
boxloop2:
	call printchr
	call printchr
	add word [es:cursor], 2 * 76
	call printchr
	call printchr
	dec cl
	jnz boxloop2


	mov word [es:cursor], 160 * 7 + 8
	xor ax, ax
	mov dx, 1
	mov cx, 17

fibloop:
	add dx, ax
	call printnum
	push ax
	mov ax, ' '
	call printchr
	pop ax
	xchg ax, dx
	dec cx
	jnz fibloop


	mov word [es:cursor], 160 * 9 + 8
	mov cx, 0

squareloop:
	mov ax, cx
	call calcsq
	call printnum
	mov ax, ' '
	call printchr
	inc cx
	cmp cx, 20
	jbe squareloop
	


	%define count 100
	mov word [es:cursor], 160 * 11 + 8
	mov bx, 2

primeloop:
	or byte [es:memory + bx], 0
	jnz primecont
	mov ax, bx
	call printnum
	mov ax, ' '
	call printchr
	mov di, bx
primeloop_inner:
	or byte [es:memory + di], 1
	add di, bx
	cmp di, count + 1
	jbe primeloop_inner

primecont:
	inc bx
	cmp bx, count
	jbe primeloop


	; all done
	jmp halt


calcsq:
	mov bx, ax
	xor dx, dx
	or bx, bx
calcsqloop:
	jz calcsqfinish
	add dx, ax
	dec bx
	jmp calcsqloop
calcsqfinish:
	mov ax, dx
	ret


print:
	push bx
	push dx
	mov bx, ax
printloop:
	mov dl, [es:bx]
	inc bx
	xchg al, dl
	call printchr
	xchg al, dl
	and dl, dl
	jnz printloop
	pop dx
	pop bx
	ret

printchr:
	push bx
	push di
	mov bx, 8000h
	mov di, [es:cursor]
	mov [bx+di], al
	inc di
	inc di
	mov [es:cursor], di
	pop di
	pop bx
	ret

printnl:
	mov di, [es:cursor]
printnlloop:
	sub di, 160
	jns printnlloop
	sub [es:cursor], di
	ret

printnum:
	push bx
	push ax
	mov bl, '0'
	cmp ax, 9
	jbe numcont_1digit
	cmp ax, 99
	jbe numloop_2digit
numloop_3digit:
	sub ax, 100
	inc bl
	cmp ax, 99
	jnbe numloop_3digit
	xchg bl, al
	call printchr
	xchg bl, al
	mov bl, '0'
numloop_2digit:
	cmp ax, 9
	jbe numcont_2digit
	sub ax, 10
	inc bx
	jmp numloop_2digit
numcont_2digit:
	xchg al, bl
	call printchr
	mov al, bl
numcont_1digit:
	add al, '0'
	call printchr
	pop ax
	pop bx
	ret

clear:
	push bx
	push di
	mov bx, 8000h
	mov di, 80 * 25 * 2
clearloop:
	mov word [bx+di], 0700h
	dec di
	dec di
	jnz clearloop
	pop di
	pop bx
	ret
	
	

hello:
	db 'Hello, world!', 0

cursor:
	dw 0

memory:
	times 101 db 0

